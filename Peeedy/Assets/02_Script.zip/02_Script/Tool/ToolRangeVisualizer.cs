using System;
using UnityEngine;

public class ToolRangeVisualizer : MonoBehaviour
{
    [SerializeField] private EventChannelSO toolInfoCallEventChannel;
    [SerializeField] private GameObject visualizerObj;
    [SerializeField] private LayerMask dummyLayer;
    private bool _isToolEquiped = false;
    private Transform _equipedToolTran;
    private Material _objMat;

    private void Awake()
    {
        _objMat = visualizerObj.GetComponent<MeshRenderer>().materials[0];
    }

    private void OnEnable()
    {
        toolInfoCallEventChannel.AddListener<ToolEquipEvent>(HandleToolEquipEvt);
        toolInfoCallEventChannel.AddListener<ToolUnEquipEvent>(HandleToolunEquipEvt);
    }
    private void OnDisable()
    {
        toolInfoCallEventChannel.RemoveListener<ToolEquipEvent>(HandleToolEquipEvt);
        toolInfoCallEventChannel.RemoveListener<ToolUnEquipEvent>(HandleToolunEquipEvt);
    }

    private void Update()
    {
        if (_isToolEquiped)
        {
            gameObject.transform.position = new Vector3(_equipedToolTran.position.x, 0, _equipedToolTran.position.z);

            Collider[] hits = Physics.OverlapSphere(transform.position, 1f, dummyLayer);
            foreach (Collider c in hits)
            {
                Debug.Log("���̰���");
            }
        }
    }

    private void HandleToolEquipEvt(ToolEquipEvent @event)
    {
        _isToolEquiped = true;
        _equipedToolTran = @event.ToolPosition;
        visualizerObj.SetActive(true);

        int range = @event.ToolSO.toolDetectRange;
        SetObjScale(range);
    }

    private void HandleToolunEquipEvt(ToolUnEquipEvent @event)
    {
        _isToolEquiped = false;
        visualizerObj.SetActive(false);
    }

    private void SetObjScale(int scale) // �ʺ� / ���� �� ���� ����� ����
    {
        //visualizerObj.transform.localScale = new Vector3(scale, 0, scale);

        //float currentScale = transform.localScale.x; // X�� Z�� ���ٴ� ����
        //float baseScale = 2.0f; // ���� ������ �Ǵ� ������

        //float newWidth = 0.93f * (currentScale / baseScale);
        //float newLength = 0.51f * (currentScale / baseScale);

        //_objMat.SetFloat("_LineWidth", newWidth);
        //_objMat.SetFloat("_LineLength", newLength);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, 1f);
    }
}
