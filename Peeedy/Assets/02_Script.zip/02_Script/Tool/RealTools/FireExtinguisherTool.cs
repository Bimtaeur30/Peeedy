using UnityEngine;

public class FireExtinguisherTool : Tool
{
    public override void EquipTool()
    {
        base.EquipTool();
    }

    public override void UnEquipTool()
    {
        base.UnEquipTool();
    }
}
