using System.Runtime.InteropServices;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class ToolInfoViewer : MonoBehaviour
{
    [SerializeField] private EventChannelSO toolInfoCallEventChannel;
    [SerializeField] private GameObject toolInfoLabelUI;
    [SerializeField] private TextMeshProUGUI toolNameTxt;
    [SerializeField] private TextMeshProUGUI keyTxt;

    private bool _isInfoActivate;
    private Transform _currentSelectedTool;

    private void OnEnable()
    {
        toolInfoCallEventChannel.AddListener<ToolInfoCallEvent>(HandleToolInfoCallEvt);
        toolInfoCallEventChannel.AddListener<ToolEquipEvent>(HandleToolEquipEvt);
        toolInfoCallEventChannel.AddListener<ToolUnEquipEvent>(HandleToolunEquipEvt);
    }
    private void OnDisable()
    {
        toolInfoCallEventChannel.RemoveListener<ToolInfoCallEvent>(HandleToolInfoCallEvt);
        toolInfoCallEventChannel.RemoveListener<ToolEquipEvent>(HandleToolEquipEvt);
        toolInfoCallEventChannel.RemoveListener<ToolUnEquipEvent>(HandleToolunEquipEvt);
    }
    private void Update()
    {
        if (_isInfoActivate)
        {
            transform.position = _currentSelectedTool.position + new Vector3(0, 0, -0.01f); // ��ħ ����
        }
    }

    private bool _isEquiped = false; // ���� ���� ����

    private void HandleToolInfoCallEvt(ToolInfoCallEvent evt)
    {
        // �̹� ���� ���̶�� �ٴڿ� �ִ� �ٸ� ������ Label ��û�� �����մϴ�.
        if (_isEquiped) return;

        _isInfoActivate = evt.IsActivate;
        toolInfoLabelUI.gameObject.SetActive(evt.IsActivate);

        if (evt.IsActivate)
        {
            toolNameTxt.text = evt.ToolSO.toolName;
            keyTxt.text = "E"; // �⺻ �ݱ� Ű
            _currentSelectedTool = evt.ToolPosition;
        }
    }

    private void HandleToolEquipEvt(ToolEquipEvent evt)
    {
        _isEquiped = true;
        _isInfoActivate = true; // ���� �߿��� ��ġ ������Ʈ�� ��� ����

        toolInfoLabelUI.gameObject.SetActive(true); // Ȥ�� �����ٸ� �ٽ� Ŵ
        keyTxt.text = "Q";
        toolNameTxt.text = "��������";
    }

    private void HandleToolunEquipEvt(ToolUnEquipEvent evt)
    {
        _isEquiped = false;
        toolInfoLabelUI.gameObject.SetActive(false); // ���������� �ϴ� UI ��
    }
}
