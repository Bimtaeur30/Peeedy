using UnityEngine;

public enum NuisanceTagEnum
{
    None, Noisiness, Vandalism
}
