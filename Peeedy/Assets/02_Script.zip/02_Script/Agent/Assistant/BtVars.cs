using UnityEngine;

public static class BtVars
{
    public const string TargetGameObject = "TargetGameObject";
    public const string State = "State";
    public const string Bot = "Bot";
    public const string StateChannel = "StateChannel";
}
