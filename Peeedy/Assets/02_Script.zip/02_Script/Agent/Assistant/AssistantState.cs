using Unity.Behavior;
using UnityEngine;

[BlackboardEnum]
public enum AssistantState
{
    IDLE = 0,
    MOVE = 1
}
