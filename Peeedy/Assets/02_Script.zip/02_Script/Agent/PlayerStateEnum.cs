
    public enum PlayerStateEnum
    {
        IDLE = 0,WALK = 1
    }
    