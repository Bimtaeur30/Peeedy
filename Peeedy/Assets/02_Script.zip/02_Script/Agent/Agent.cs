using UnityEngine;

public abstract class Agent : ModuleOwner
{
    protected virtual void Start()
    {

    }
}
