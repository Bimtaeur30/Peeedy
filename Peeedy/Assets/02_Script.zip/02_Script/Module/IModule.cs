using UnityEngine;

public interface IModule
{
    void Initialize(ModuleOwner owner);
}
