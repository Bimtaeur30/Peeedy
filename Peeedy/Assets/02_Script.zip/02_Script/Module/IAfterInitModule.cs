using UnityEngine;

public interface IAfterInitModule
{
    void AfterIniit();
}
