using System.Collections;
using UnityEngine;

public class ChatParent : MonoBehaviour
{
    [SerializeField] private Chat chatPrefab;
    [SerializeField] private float chatLiftTime = 1.5f;
    Chat _currentChat;
    private Coroutine _chatTimerCoroutine;

    private void Start()
    {
        StartCoroutine(AA());
    }

    public void NewChat(string message)
    {
        _currentChat?.Close();

        _currentChat = Instantiate(chatPrefab, transform);
        _currentChat.Setup(message);

        if (_chatTimerCoroutine != null)
            StopCoroutine(_chatTimerCoroutine);

        _chatTimerCoroutine = StartCoroutine(ChatTimer());
    }


    IEnumerator ChatTimer()
    {
        yield return new WaitForSeconds(chatLiftTime);
        _currentChat?.Close();
        _currentChat = null;
    }

    IEnumerator AA()
    {
        while(true)
        {
            yield return new WaitForSeconds(1f);
            NewChat("���� ���� ���� �׷� ���� ���״�");
        }
    }
}
