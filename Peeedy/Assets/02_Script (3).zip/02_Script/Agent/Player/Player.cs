using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class Player : Agent
{
    [SerializeField] private StateListSO stateList;

    private AgentStateMachine _stateMachine;
    private ICombatModule _combatModule;
    public ToolHandlerModule ToolHandlerModule { get; private set; }

    [field:SerializeField] public PlayerInputSO PlayerInput { get; private set; }

    protected override void InitializeComponents()
    {
        base.InitializeComponents();
        _stateMachine = new AgentStateMachine(this, stateList.states);
    }

    protected override void AfterInitComponents()
    {
        base.AfterInitComponents();
        _combatModule = GetModule<ICombatModule>();
        ToolHandlerModule = GetModule<ToolHandlerModule>();

        PlayerInput.LeftMouseClickEvent += HandleAttackKeyPressed;
        PlayerInput.OnToolEquipEvent += HandleToolEquipKeyPressed;
        PlayerInput.OnToolUnEquipEvent += HandleToolUnEquipKeyPressed;
        PlayerInput.OnToolSaveInventoryEvent += HandleToolSaveInventoryKeyPressed;
    }

    private void OnDisable()
    {
        PlayerInput.LeftMouseClickEvent -= HandleAttackKeyPressed;
        PlayerInput.OnToolEquipEvent -= HandleToolEquipKeyPressed;
        PlayerInput.OnToolUnEquipEvent -= HandleToolUnEquipKeyPressed;
        PlayerInput.OnToolSaveInventoryEvent -= HandleToolSaveInventoryKeyPressed;
    }

    private void HandleToolSaveInventoryKeyPressed()
    {
        ToolHandlerModule.SaveToolInventory();
    }

    private void HandleToolUnEquipKeyPressed()
    {
        ToolHandlerModule.UnEquipTool();
    }

    private void HandleToolEquipKeyPressed()
    {
        ToolHandlerModule.EquipTool();
    }

    private void HandleAttackKeyPressed()
    {
        _combatModule.Attack();
    }

    protected override void Start()
    {
        base.Start();
        _stateMachine.ChangeState((int)PlayerStateEnum.IDLE);
    }

    private void Update()
    {
        _stateMachine.UpdateMachine();

        // ���콺 ��ġ�� ������
        Vector3 mousePos = Input.mousePosition;

        // ī�޶�� ������Ʈ ������ �Ÿ��� Z������ �־���� ��Ȯ�� ���� ��ǥ�� ���ɴϴ�.
        // ���� ī�޶� Z: -10, �÷��̾ Z: 0�� �ִٸ� �Ÿ��� 10�Դϴ�.
        mousePos.z = Mathf.Abs(Camera.main.transform.position.z - transform.position.z);

        Vector3 worldMousePos = Camera.main.ScreenToWorldPoint(mousePos);
        _combatModule.Aim(worldMousePos);
    }

    public void ChangeState(PlayerStateEnum newState)
    {
        _stateMachine.ChangeState((int)newState);
    }

    public AgentState GetCurrentState() => _stateMachine.CurrentState;
}
