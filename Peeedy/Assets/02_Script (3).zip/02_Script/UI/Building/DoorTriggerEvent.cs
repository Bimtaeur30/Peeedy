using UnityEditor.Analytics;
using UnityEngine;

public class DoorTriggerEvent : GameEvent
{
    public BuildingSO BuildingSO;
    public bool IsEnter;
    public DoorType DoorType;
    public DoorTriggerEvent(DoorType doorType, BuildingSO buildingSO, bool isEnter) // true = ����, false = ����
    {
        DoorType = doorType;
        BuildingSO = buildingSO;
        IsEnter = isEnter;
    }
}
